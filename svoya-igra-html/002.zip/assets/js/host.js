// assets/js/host.js
// Ведущий: табло (iframe) + окно вопроса + начисление очков по стоимости активного вопроса
// ВАЖНО: is_used ставим ТОЛЬКО на "Назад на табло"

console.log("HOST.JS VERSION: 2026-01-06 used-on-back + open-on-new-pick");

(async function init() {
  const params = new URLSearchParams(location.search);
  const gameId = params.get("gameId");

  const statusEl = document.getElementById("status");
  const debugEl = document.getElementById("debug");

  const btnBoard = document.getElementById("btnBoard"); // "Табло"
  const btnShowAnswer = document.getElementById("btnShowAnswer"); // "Показать ответ"
  const btnBackToBoard = document.getElementById("btnBackToBoard"); // "Назад на табло"

  const hostTabloWrap = document.getElementById("hostTabloWrap");
  const hostTabloFrame = document.getElementById("hostTabloFrame");
  const hostMain = document.getElementById("hostMain");

  const playersCountEl = document.getElementById("playersCount");
  const btnApplyPlayers = document.getElementById("btnApplyPlayers");
  const btnResetScores = document.getElementById("btnResetScores");
  const playersListHostEl = document.getElementById("playersListHost");

  const client = window.supabase;

  function setStatus(t) {
    if (statusEl) statusEl.textContent = t;
  }
  function log(obj) {
    if (!debugEl) return;
    debugEl.textContent = typeof obj === "string" ? obj : JSON.stringify(obj, null, 2);
  }

  if (!client || typeof client.from !== "function") {
    setStatus("❌ Supabase не подключён (проверь supabase.js)");
    return;
  }
  if (!gameId) {
    setStatus("❌ Нет gameId в URL (?gameId=...)");
    return;
  }

  // --------------------------
  // helpers
  // --------------------------
  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
  const safeInt = (v, d) => {
    const n = Number(v);
    return Number.isFinite(n) ? n : d;
  };

  function detectIdxBase(players) {
    return (players || []).some((p) => Number(p.idx) === 0) ? 0 : 1;
  }

  // --------------------------
  // state
  // --------------------------
  let idxBase = 1;
  let currentGame = null;
  let players = [];

  let activeQuestion = null;
  let activeValue = 0;

  let questionWin = null;

  // чтобы не открывать окно при старте
  let lastQuestionId = null;
  let didInit = false;

  // --------------------------
  // UI: Tablo iframe
  // --------------------------
  function openTablo() {
    if (!hostTabloWrap || !hostTabloFrame || !hostMain) return;

    hostMain.classList.add("hidden");
    hostTabloWrap.style.display = "block";

    // tv=1 красивый вид, host=1 разрешаем клики
    hostTabloFrame.src = `../play/index.html?gameId=${encodeURIComponent(gameId)}&tv=1&host=1`;
  }

  function closeTablo() {
    if (!hostTabloWrap || !hostTabloFrame || !hostMain) return;

    hostTabloWrap.style.display = "none";
    hostMain.classList.remove("hidden");
    hostTabloFrame.src = "about:blank";
  }

  function openQuestionWindow() {
    const url = `../question/index.html?gameId=${encodeURIComponent(gameId)}`;

    if (questionWin && !questionWin.closed) {
      questionWin.focus();
      return;
    }

    questionWin = window.open(url, "QuestionWindow", "width=1200,height=800");
    if (!questionWin) {
      setStatus("❌ Браузер заблокировал окно вопроса. Разреши всплывающие окна для 127.0.0.1");
    }
  }

  function closeQuestionWindow() {
    try {
      if (questionWin && !questionWin.closed) questionWin.close();
    } catch {}
    questionWin = null;
  }

  // --------------------------
  // DB loaders
  // --------------------------
  async function loadGame() {
    const { data, error } = await client
      .from("games")
      .select("id,title,phase,active_question_id,show_answer")
      .eq("id", gameId)
      .single();
    if (error) throw error;
    return data;
  }

  async function loadPlayers() {
    const { data, error } = await client
      .from("players")
      .select("id,game_id,idx,name,score,avatar_url")
      .eq("game_id", gameId)
      .order("idx", { ascending: true });
    if (error) throw error;
    return data || [];
  }

  async function loadQuestionById(questionId) {
    if (!questionId) return null;
    const { data, error } = await client
      .from("questions")
      .select("id, game_id, round, topic_idx, value, qtype, question_text, answer_text, media_url, is_used")
      .eq("id", questionId)
      .single();

    if (error) {
      console.error("loadQuestionById error:", error);
      return null;
    }
    return data;
  }

  // --------------------------
  // Game actions
  // --------------------------
  async function setGamePatch(patch) {
    const { error } = await client.from("games").update(patch).eq("id", gameId);
    if (error) throw error;
  }

  async function showAnswer() {
    await setGamePatch({ phase: "answer", show_answer: true });
  }

  async function backToBoard() {
    // ✅ Помечаем использованным ТОЛЬКО здесь (после начисления очков)
    if (currentGame?.active_question_id) {
      const { error: qErr } = await client
        .from("questions")
        .update({ is_used: true })
        .eq("id", currentGame.active_question_id);

      if (qErr) {
        console.error("mark used error:", qErr);
      }
    }

    // Вернуться на табло и очистить выбор вопроса
    await setGamePatch({ phase: "board", show_answer: false, active_question_id: null });

    // локально тоже очистим
    activeQuestion = null;
    activeValue = 0;
  }

  // --------------------------
  // Players actions
  // --------------------------
  async function ensurePlayersCount(targetCount) {
    targetCount = clamp(targetCount, 2, 6);

    players = await loadPlayers();
    idxBase = detectIdxBase(players);

    const wantedIdx = [];
    for (let i = 0; i < targetCount; i++) wantedIdx.push(idxBase + i);

    const byIdx = new Map(players.map((p) => [Number(p.idx), p]));

    const toInsert = [];
    for (const idx of wantedIdx) {
      if (!byIdx.has(idx)) {
        toInsert.push({
          game_id: gameId,
          idx,
          name: `Игрок ${idx - idxBase + 1}`,
          score: 0,
          avatar_url: "",
        });
      }
    }

    if (toInsert.length) {
      const { error } = await client.from("players").insert(toInsert);
      if (error) throw error;
    }

    players = await loadPlayers();
    idxBase = detectIdxBase(players);

    if (playersCountEl) playersCountEl.value = String(targetCount);
    renderPlayersHost(targetCount);
  }

  async function resetScores() {
    const { error } = await client
      .from("players")
      .update({ score: 0 })
      .eq("game_id", gameId);
    if (error) throw error;

    players = await loadPlayers();
    renderPlayersHost(safeInt(playersCountEl?.value, 2));
  }

  async function updatePlayer(id, patch) {
    const { error } = await client.from("players").update(patch).eq("id", id);
    if (error) throw error;
  }

  // --------------------------
  // Render Players UI
  // --------------------------
  function renderPlayersHost(targetCount) {
    if (!playersListHostEl) return;
    playersListHostEl.innerHTML = "";

    const count = clamp(safeInt(targetCount, 2), 2, 6);

    const wantedIdx = [];
    for (let i = 0; i < count; i++) wantedIdx.push(idxBase + i);

    const byIdx = new Map(players.map((p) => [Number(p.idx), p]));

    wantedIdx.forEach((idx) => {
      const p = byIdx.get(idx);
      if (!p) return;

      const row = document.createElement("div");
      row.className = "player-row";

      const avatar = document.createElement("img");
      avatar.className = "player-avatar";
      avatar.alt = p.name || "player";
      avatar.src = p.avatar_url || "../assets/img/avatar_default.png";

      const nameInput = document.createElement("input");
      nameInput.className = "player-name-input";
      nameInput.type = "text";
      nameInput.value = p.name || "";
      nameInput.placeholder = `Игрок ${idx - idxBase + 1}`;

      const score = document.createElement("div");
      score.className = "player-score";
      score.textContent = String(p.score ?? 0);

      const btnMinus100 = document.createElement("button");
      btnMinus100.type = "button";
      btnMinus100.textContent = "−100";
      btnMinus100.className = "btn small";

      const btnPlus100 = document.createElement("button");
      btnPlus100.type = "button";
      btnPlus100.textContent = "+100";
      btnPlus100.className = "btn small";

      const btnMinusQ = document.createElement("button");
      btnMinusQ.type = "button";
      btnMinusQ.textContent = activeValue ? `−${activeValue}` : "−?";
      btnMinusQ.className = "btn small";

      const btnPlusQ = document.createElement("button");
      btnPlusQ.type = "button";
      btnPlusQ.textContent = activeValue ? `+${activeValue}` : "+?";
      btnPlusQ.className = "btn small";

      if (!activeValue) {
        btnMinusQ.disabled = true;
        btnPlusQ.disabled = true;
      }

      row.appendChild(avatar);
      row.appendChild(nameInput);
      row.appendChild(score);
      row.appendChild(btnMinus100);
      row.appendChild(btnPlus100);
      row.appendChild(btnMinusQ);
      row.appendChild(btnPlusQ);

      playersListHostEl.appendChild(row);

      nameInput.addEventListener("change", async () => {
        try {
          await updatePlayer(p.id, { name: nameInput.value.trim() || p.name });
        } catch (e) {
          console.error(e);
          setStatus("❌ Ошибка имени");
          log(e);
        }
      });

      btnMinus100.addEventListener("click", async () => {
        try {
          await updatePlayer(p.id, { score: safeInt(p.score, 0) - 100 });
        } catch (e) {
          console.error(e);
          setStatus("❌ Ошибка счёта");
          log(e);
        }
      });

      btnPlus100.addEventListener("click", async () => {
        try {
          await updatePlayer(p.id, { score: safeInt(p.score, 0) + 100 });
        } catch (e) {
          console.error(e);
          setStatus("❌ Ошибка счёта");
          log(e);
        }
      });

      btnMinusQ.addEventListener("click", async () => {
        if (!activeValue) return;
        try {
          await updatePlayer(p.id, { score: safeInt(p.score, 0) - activeValue });
        } catch (e) {
          console.error(e);
          setStatus("❌ Ошибка начисления");
          log(e);
        }
      });

      btnPlusQ.addEventListener("click", async () => {
        if (!activeValue) return;
        try {
          await updatePlayer(p.id, { score: safeInt(p.score, 0) + activeValue });
        } catch (e) {
          console.error(e);
          setStatus("❌ Ошибка начисления");
          log(e);
        }
      });
    });
  }

  // --------------------------
  // Realtime subscribe
  // --------------------------
  async function handleGameUpdate(newGame) {
    const prevQuestionId = lastQuestionId;
    lastQuestionId = newGame.active_question_id;

    currentGame = newGame;

    // стоимость считаем только если есть active_question_id
    if (currentGame.active_question_id) {
      activeQuestion = await loadQuestionById(currentGame.active_question_id);
      activeValue = activeQuestion?.value ? Number(activeQuestion.value) : 0;
    } else {
      activeQuestion = null;
      activeValue = 0;
    }

    // открываем окно только на НОВЫЙ выбор (и не при старте)
    const isNewPick =
      !!newGame.active_question_id && newGame.active_question_id !== prevQuestionId;

    if (didInit && isNewPick && (newGame.phase === "question" || newGame.phase === "answer")) {
      openQuestionWindow();
    }

    // при board — закрываем окно вопроса
    if (newGame.phase === "board") {
      closeQuestionWindow();
    }

    renderPlayersHost(safeInt(playersCountEl?.value, 2));
    setStatus(`🎮 ${currentGame?.title || "Игра"} | phase: ${currentGame?.phase} | +${activeValue || "?"}`);

    didInit = true;
  }

  function subscribeRealtime() {
    client
      .channel(`host:game:${gameId}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "games", filter: `id=eq.${gameId}` },
        async (payload) => {
          await handleGameUpdate(payload.new);
        }
      )
      .subscribe();

    client
      .channel(`host:players:${gameId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "players", filter: `game_id=eq.${gameId}` },
        async () => {
          players = await loadPlayers();
          idxBase = detectIdxBase(players);
          renderPlayersHost(safeInt(playersCountEl?.value, 2));
        }
      )
      .subscribe();
  }

  // --------------------------
  // Boot
  // --------------------------
  try {
    setStatus("⏳ Загрузка…");

    currentGame = await loadGame();

    // ✅ ЖЕЛЕЗНЫЙ СБРОС при входе ведущего (чтобы не было авто-вопроса)
    if (currentGame.phase !== "board" || currentGame.active_question_id) {
      await setGamePatch({ phase: "board", show_answer: false, active_question_id: null });
      currentGame = await loadGame();
    }

    players = await loadPlayers();
    idxBase = detectIdxBase(players);

    const initialCount = clamp(players.length || 2, 2, 6);
    if (playersCountEl) playersCountEl.value = String(initialCount);

    renderPlayersHost(initialCount);

    btnBoard?.addEventListener("click", openTablo);

    btnBackToBoard?.addEventListener("click", async () => {
      try {
        await backToBoard();
        closeTablo();
        closeQuestionWindow();
      } catch (e) {
        console.error(e);
        setStatus("❌ Ошибка: назад на табло");
        log(e);
      }
    });

    btnShowAnswer?.addEventListener("click", async () => {
      try {
        await showAnswer();
      } catch (e) {
        console.error(e);
        setStatus("❌ Ошибка: показать ответ");
        log(e);
      }
    });

    btnApplyPlayers?.addEventListener("click", async () => {
      try {
        const cnt = safeInt(playersCountEl?.value, 2);
        await ensurePlayersCount(cnt);
        setStatus("✅ Игроки применены");
      } catch (e) {
        console.error(e);
        setStatus("❌ Ошибка: применить игроков");
        log(e);
      }
    });

    btnResetScores?.addEventListener("click", async () => {
      try {
        await resetScores();
        setStatus("✅ Очки сброшены");
      } catch (e) {
        console.error(e);
        setStatus("❌ Ошибка: сброс очков");
        log(e);
      }
    });

    // применим состояние (окно не откроется — didInit=false)
    await handleGameUpdate(currentGame);

    subscribeRealtime();
  } catch (e) {
    console.error(e);
    setStatus("❌ Ошибка host.js: " + (e?.message || String(e)));
    log(e);
  }
})();
