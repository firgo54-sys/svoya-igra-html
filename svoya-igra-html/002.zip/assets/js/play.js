// assets/js/play.js
// TABLO ONLY: показывает только табло + игроков, не переключается на экран вопроса.
// Клик по клетке (для ведущего) -> обновляет games.phase/question + active_question_id.
// used НЕ ставим здесь.

(async function init() {
  const params = new URLSearchParams(location.search);

  const gameId = params.get("gameId");
  if (!gameId) {
    alert("gameId не передан");
    throw new Error("gameId missing");
  }

  const supabase = window.supabase;
  if (!supabase) {
    alert("supabase не подключен (проверь supabase.js)");
    throw new Error("supabase missing");
  }

  // TV режим (только визуал). host=1 включает клики.
  const isTv = params.get("tv") === "1";
  const isHost = params.get("host") === "1";
  if (isTv) document.documentElement.classList.add("tv");

  // раунд: у тебя сейчас round=0
  const round = Number(params.get("round") ?? 0);

  let players = [];
  let questionsIndex = new Map(); // key: `${topic_idx}:${value}` -> q row

  const playersBarEl = document.getElementById("playersBar");
  const boardEl = document.getElementById("board");

  // ------------------------
  // players render
  // ------------------------
  function renderPlayersBar() {
    if (!playersBarEl) return;

    playersBarEl.innerHTML = "";
    players.forEach((p) => {
      const chip = document.createElement("div");
      chip.className = "player-chip";

      const img = document.createElement("img");
      img.alt = p.name || `Игрок ${p.idx}`;
      img.src = p.avatar_url || "";
      if (!p.avatar_url) img.style.visibility = "hidden";

      const nm = document.createElement("div");
      nm.className = "nm";
      nm.textContent = p.name || `Игрок ${p.idx}`;

      const sc = document.createElement("div");
      sc.className = "sc";
      sc.textContent = String(p.score ?? 0);

      chip.appendChild(img);
      chip.appendChild(nm);
      chip.appendChild(sc);
      playersBarEl.appendChild(chip);
    });
  }

  // ------------------------
  // DB loaders
  // ------------------------
  async function loadPlayers() {
    const { data, error } = await supabase
      .from("players")
      .select("*")
      .eq("game_id", gameId)
      .order("idx", { ascending: true });

    if (error) {
      console.error("loadPlayers error:", error);
      return [];
    }
    return data || [];
  }

  async function loadTopics() {
    const { data, error } = await supabase
      .from("topics")
      .select("idx,title")
      .eq("game_id", gameId)
      .eq("round", round)
      .order("idx", { ascending: true });

    if (error) {
      console.error("loadTopics error:", error);
      return [];
    }
    return data || [];
  }

  async function loadQuestions() {
    const { data, error } = await supabase
      .from("questions")
      .select("id, topic_idx, value, prompt, answer, type, media_url, is_used")
      .eq("game_id", gameId)
      .eq("round", round);

    if (error) {
      console.error("loadQuestions error:", error);
      return [];
    }
    return data || [];
  }

  // ------------------------
  // Board fill
  // ------------------------
  function fillBoardTopics(topics) {
    if (!boardEl) return;

    const topicCells = boardEl.querySelectorAll("td.topic");
    topicCells.forEach((cell, i) => {
      const t = topics.find((x) => Number(x.idx) === i);
      cell.textContent = (t?.title || `ТЕМА ${i + 1}`).toUpperCase();
    });
  }

  function buildQuestionsIndex(list) {
    questionsIndex = new Map();
    list.forEach((q) => {
      const key = `${Number(q.topic_idx)}:${Number(q.value)}`;
      questionsIndex.set(key, q);
    });
  }

  function markUsedCells() {
    if (!boardEl) return;

    const valueCells = boardEl.querySelectorAll("td.value");
    valueCells.forEach((cell) => {
      const topicIdx = Number(cell.dataset.topicIdx);
      const val = Number(cell.dataset.value);
      const key = `${topicIdx}:${val}`;
      const q = questionsIndex.get(key);

      // если вопроса нет — считаем незаполненным, но цифры оставляем
      if (!q) {
        cell.classList.remove("used");
        return;
      }

      if (q.is_used) cell.classList.add("used");
      else cell.classList.remove("used");
    });
  }

  function attachCellDataAttrs() {
    if (!boardEl) return;

    const rows = boardEl.querySelectorAll("tbody tr");
    rows.forEach((tr, topicIdx) => {
      const cells = tr.querySelectorAll("td.value");
      const values = [100, 200, 300, 400, 500];
      cells.forEach((cell, j) => {
        cell.dataset.topicIdx = String(topicIdx);
        cell.dataset.value = String(values[j] ?? "");
      });
    });
  }

  // ------------------------
  // Click -> open question (host only)
  // ------------------------
  async function openQuestionFromCell(topicIdx, value) {
    const key = `${Number(topicIdx)}:${Number(value)}`;
    const q = questionsIndex.get(key);

    if (!q) return;
    if (q.is_used) return;

    // если prompt пустой — не открываем
    if (!String(q.prompt || "").trim()) return;

    const { error } = await supabase
      .from("games")
      .update({
        phase: "question",
        active_question_id: q.id,
        show_answer: false,
      })
      .eq("id", gameId);

    if (error) console.error("openQuestion update games error:", error);
  }

  function bindBoardClicks() {
    if (!boardEl) return;

    // В tv=1 клики выключены, кроме host=1
    if (isTv && !isHost) return;

    boardEl.addEventListener("click", (e) => {
      const cell = e.target?.closest?.("td.value");
      if (!cell) return;

      if (cell.classList.contains("used")) return;

      const topicIdx = Number(cell.dataset.topicIdx);
      const value = Number(cell.dataset.value);
      if (!Number.isFinite(topicIdx) || !Number.isFinite(value)) return;

      openQuestionFromCell(topicIdx, value);
    });
  }

  // ------------------------
  // Boot
  // ------------------------
  attachCellDataAttrs();
  bindBoardClicks();

  const [tpcs, qs] = await Promise.all([loadTopics(), loadQuestions()]);
  fillBoardTopics(tpcs);
  buildQuestionsIndex(qs);
  markUsedCells();

  players = await loadPlayers();
  renderPlayersBar();

  // ------------------------
  // Realtime
  // ------------------------
  supabase
    .channel(`play:${gameId}`)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "players", filter: `game_id=eq.${gameId}` },
      async () => {
        players = await loadPlayers();
        renderPlayersBar();
      }
    )
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "topics", filter: `game_id=eq.${gameId}` },
      async () => {
        const t = await loadTopics();
        fillBoardTopics(t);
      }
    )
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "questions", filter: `game_id=eq.${gameId}` },
      async () => {
        const list = await loadQuestions();
        buildQuestionsIndex(list);
        markUsedCells();
      }
    )
    .subscribe();
})();
