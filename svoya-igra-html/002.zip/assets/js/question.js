// assets/js/question.js
(async function initQuestion() {
  const client = window.supabase;
  const params = new URLSearchParams(location.search);
  const gameId = params.get("gameId");

  const qTopic = document.getElementById("qTopic");
  const qValue = document.getElementById("qValue");
  const qPrompt = document.getElementById("qPrompt");
  const qAnswer = document.getElementById("qAnswer");
  const qImage = document.getElementById("qImage");
  const qAudio = document.getElementById("qAudio");

  if (!client) {
    console.error("supabase client not found");
    return;
  }
  if (!gameId) {
    if (qPrompt) qPrompt.textContent = "Нет gameId в ссылке (?gameId=...)";
    return;
  }

  function hide(el) { el && el.classList.add("hidden"); }
  function show(el) { el && el.classList.remove("hidden"); }

  function resetMedia() {
    if (qImage) { qImage.src = ""; hide(qImage); }
    if (qAudio) { try { qAudio.pause(); } catch {} qAudio.src = ""; hide(qAudio); }
  }

  function showWaiting() {
    resetMedia();
    if (qTopic) qTopic.textContent = "";
    if (qValue) qValue.textContent = "";
    if (qPrompt) qPrompt.textContent = "Ожидание вопроса…";
    if (qAnswer) { qAnswer.textContent = ""; hide(qAnswer); }
  }

  async function loadQuestion(questionId) {
    const { data, error } = await client
      .from("questions")
      .select("id, game_id, round, topic_idx, value, type, prompt, answer, media_url")
      .eq("id", questionId)
      .single();

    if (error) {
      console.error("loadQuestion error:", error);
      return null;
    }
    return data;
  }

  async function applyGameState(game) {
    // ✅ КЛЮЧЕВОЕ: если board — не показываем вопрос вообще
    if (!game || game.phase === "board") {
      showWaiting();
      return;
    }

    if (!game.active_question_id) {
      showWaiting();
      return;
    }

    const q = await loadQuestion(game.active_question_id);
    if (!q) {
      if (qPrompt) qPrompt.textContent = "Не удалось загрузить вопрос";
      return;
    }

    resetMedia();

    if (qTopic) qTopic.textContent = q.topic_idx != null ? `Тема ${Number(q.topic_idx) + 1}` : "";
    if (qValue) qValue.textContent = q.value != null ? String(q.value) : "";
    if (qPrompt) qPrompt.textContent = q.prompt || "";

    if (q.type === "image" && q.media_url && qImage) {
      qImage.src = q.media_url;
      show(qImage);
    }

    if (q.type === "audio" && q.media_url && qAudio) {
      qAudio.src = q.media_url;
      show(qAudio);
    }

    if (qAnswer) {
      qAnswer.textContent = q.answer || "";
      if (game.phase === "answer" || game.show_answer) show(qAnswer);
      else hide(qAnswer);
    }
  }

  async function loadGameOnce() {
    const { data, error } = await client
      .from("games")
      .select("id, phase, active_question_id, show_answer")
      .eq("id", gameId)
      .single();

    if (error) {
      console.error("loadGameOnce error:", error);
      if (qPrompt) qPrompt.textContent = "Ошибка загрузки игры";
      return null;
    }
    return data;
  }

  // 1) первичная загрузка
  const game = await loadGameOnce();
  await applyGameState(game);

  // 2) realtime
  client
    .channel(`question:${gameId}`)
    .on(
      "postgres_changes",
      { event: "UPDATE", schema: "public", table: "games", filter: `id=eq.${gameId}` },
      async (payload) => {
        await applyGameState(payload.new);
      }
    )
    .subscribe();
})();
