// assets/js/host.js
// Работает и с file://, и с Live Server. Без top-level await. Все ошибки видны в статусе.

(async function init() {
  const urlParams = new URLSearchParams(window.location.search);
  const gameId = urlParams.get("gameId");

  const statusEl = document.getElementById("status");
  const debugEl = document.getElementById("debug");

  const playersCountEl = document.getElementById("playersCount");
  const playersListHostEl = document.getElementById("playersListHost");

  let currentGame = null;
  let players = [];
  let idxBase = 1; // будет 0 или 1 (определим автоматически)

  function setStatus(t) {
    if (statusEl) statusEl.textContent = t;
  }
  function log(obj) {
    if (!debugEl) return;
    debugEl.textContent = typeof obj === "string" ? obj : JSON.stringify(obj, null, 2);
  }

  try {
    if (!gameId) {
      setStatus("❌ gameId не передан");
      throw new Error("gameId missing");
    }

    if (!window.supabase) {
      setStatus("❌ window.supabase пуст (supabase.js не подключился)");
      return;
    }

    const db = window.supabase;

    // ------------------------
    // helpers
    // ------------------------
    async function updateGame(patch) {
      const { error } = await db.from("games").update(patch).eq("id", gameId);
      if (error) throw error;
    }

    async function loadGame() {
      const { data, error } = await db.from("games").select("*").eq("id", gameId).single();
      if (error) throw error;
      return data;
    }

    async function loadPlayers() {
      const { data, error } = await db
        .from("players")
        .select("id, game_id, idx, name, score, avatar_url, created_at")
        .eq("game_id", gameId)
        .order("idx", { ascending: true });

      if (error) throw error;
      return data || [];
    }

    function detectIdxBase(list) {
      // если когда-то создавали игроков с idx=0.., фиксируем базу 0
      // иначе база 1 (1..N)
      const hasZero = (list || []).some((p) => Number(p.idx) === 0);
      return hasZero ? 0 : 1;
    }

    function displayNumber(p) {
      // красивый номер 1..N для вывода
      return Number(p.idx) - idxBase + 1;
    }

    async function updatePlayerById(playerId, patch) {
      // ✅ железно: обновляем конкретную строку игрока по id
      const { data, error } = await db
        .from("players")
        .update(patch)
        .eq("id", playerId)
        .select("id, game_id, idx, name, score, avatar_url")
        .single();

      if (error) throw error;

      // ✅ сразу перерисуем UI, не ждём realtime
      players = await loadPlayers();
      idxBase = detectIdxBase(players);
      renderPlayersHost();

      return data;
    }

    async function insertMissingPlayers(targetCount) {
      const existingIdx = new Set(players.map((p) => Number(p.idx)));
      const toInsert = [];

      // создаём ровно targetCount игроков: idx = idxBase .. idxBase+targetCount-1
      for (let i = idxBase; i <= idxBase + targetCount - 1; i++) {
        if (!existingIdx.has(i)) {
          const num = i - idxBase + 1;
          toInsert.push({
            game_id: gameId,
            idx: i,
            name: `Игрок ${num}`,
            score: 0,
            avatar_url: null,
          });
        }
      }

      if (toInsert.length) {
        const { error } = await db.from("players").insert(toInsert);
        if (error) throw error;
      }
    }

    async function deleteExtraPlayers(targetCount) {
      const maxIdx = idxBase + targetCount - 1;
      const { error } = await db.from("players").delete().eq("game_id", gameId).gt("idx", maxIdx);
      if (error) throw error;
    }

    async function setPlayersCount(targetCount) {
      // перезагружаем игроков -> определяем базу -> добавляем/удаляем
      players = await loadPlayers();
      idxBase = detectIdxBase(players);

      await insertMissingPlayers(targetCount);
      await deleteExtraPlayers(targetCount);

      players = await loadPlayers();
      idxBase = detectIdxBase(players);
      renderPlayersHost();
    }

    async function resetScores() {
      const { error } = await db.from("players").update({ score: 0 }).eq("game_id", gameId);
      if (error) throw error;

      players = await loadPlayers();
      idxBase = detectIdxBase(players);
      renderPlayersHost();
    }

    async function uploadAvatarJPEG(file, player) {
      if (!file) return null;

      const isJpeg =
        file.type === "image/jpeg" ||
        file.name.toLowerCase().endsWith(".jpg") ||
        file.name.toLowerCase().endsWith(".jpeg");

      if (!isJpeg) {
        alert("Только JPEG (jpg/jpeg)");
        return null;
      }

      // ✅ путь по id, чтобы никогда не путать игроков
      const path = `${gameId}/${player.id}.jpg`;

      const { error: upErr } = await db.storage
        .from("avatars")
        .upload(path, file, { upsert: true, contentType: "image/jpeg" });

      if (upErr) throw upErr;

      const { data } = db.storage.from("avatars").getPublicUrl(path);
      const publicUrl = data?.publicUrl || null;

      if (!publicUrl) return null;

      // ✅ анти-кеш, иначе ТВ/браузер часто показывает старую картинку
      const bustedUrl = publicUrl + (publicUrl.includes("?") ? "&" : "?") + "v=" + Date.now();
      return bustedUrl;
    }

    function renderPlayersHost() {
      if (!playersListHostEl) return;
      playersListHostEl.innerHTML = "";

      players.forEach((p) => {
        const card = document.createElement("div");
        card.className = "player-card";

        const img = document.createElement("img");
        img.className = "player-avatar";
        img.alt = p.name || `Игрок ${displayNumber(p)}`;
        img.src = p.avatar_url || "";
        if (!p.avatar_url) img.style.visibility = "hidden";

        const meta = document.createElement("div");
        meta.className = "player-meta";

        const row = document.createElement("div");
        row.className = "player-row";

        const nameInput = document.createElement("input");
        nameInput.className = "player-name";
        nameInput.value = p.name || `Игрок ${displayNumber(p)}`;
        nameInput.placeholder = `Игрок ${displayNumber(p)}`;
        nameInput.addEventListener("change", async () => {
          try {
            const nextName = nameInput.value.trim() || `Игрок ${displayNumber(p)}`;
            await updatePlayerById(p.id, { name: nextName });
          } catch (e) {
            console.error(e);
            alert("Ошибка сохранения имени");
          }
        });

        const scoreBox = document.createElement("div");
        scoreBox.className = "player-score";
        scoreBox.textContent = String(p.score ?? 0);

        row.appendChild(nameInput);
        row.appendChild(scoreBox);

        const actions = document.createElement("div");
        actions.className = "player-actions";

        const btnMinus = document.createElement("button");
        btnMinus.type = "button";
        btnMinus.textContent = "−100";
        btnMinus.addEventListener("click", async () => {
          try {
            await updatePlayerById(p.id, { score: (p.score ?? 0) - 100 });
          } catch (e) {
            console.error(e);
            alert("Ошибка обновления очков");
          }
        });

        const btnPlus = document.createElement("button");
        btnPlus.type = "button";
        btnPlus.textContent = "+100";
        btnPlus.addEventListener("click", async () => {
          try {
            await updatePlayerById(p.id, { score: (p.score ?? 0) + 100 });
          } catch (e) {
            console.error(e);
            alert("Ошибка обновления очков");
          }
        });

        const btnZero = document.createElement("button");
        btnZero.type = "button";
        btnZero.textContent = "0";
        btnZero.addEventListener("click", async () => {
          try {
            await updatePlayerById(p.id, { score: 0 });
          } catch (e) {
            console.error(e);
            alert("Ошибка обновления очков");
          }
        });

        const upload = document.createElement("input");
        upload.type = "file";
        upload.accept = "image/jpeg,.jpg,.jpeg";
        upload.className = "player-upload";
        upload.addEventListener("change", async () => {
          try {
            const file = upload.files?.[0];
            if (!file) return;

            // 1) загрузили в storage
            const url = await uploadAvatarJPEG(file, p);
            if (!url) return;

            // 2) записали в players
            await updatePlayerById(p.id, { avatar_url: url });

            upload.value = "";
          } catch (e) {
            console.error(e);
            alert("Ошибка загрузки аватара (проверь bucket avatars public и права доступа)");
          }
        });

        actions.appendChild(btnMinus);
        actions.appendChild(btnPlus);
        actions.appendChild(btnZero);
        actions.appendChild(upload);

        meta.appendChild(row);
        meta.appendChild(actions);

        card.appendChild(img);
        card.appendChild(meta);

        playersListHostEl.appendChild(card);
      });

      if (playersCountEl) {
        const n = Math.min(6, Math.max(2, players.length || 2));
        playersCountEl.value = String(n);
      }
    }

    // ------------------------
    // bind buttons (phase)
    // ------------------------
    document.getElementById("btnBoard")?.addEventListener("click", async () => {
      await updateGame({ phase: "board", active_question_id: null, show_answer: false });
    });
    document.getElementById("btnShowAnswer")?.addEventListener("click", async () => {
      await updateGame({ phase: "answer", show_answer: true });
    });
    document.getElementById("btnBackToBoard")?.addEventListener("click", async () => {
      await updateGame({ phase: "board", active_question_id: null, show_answer: false });
    });

    // players controls
    document.getElementById("btnApplyPlayers")?.addEventListener("click", async () => {
      const n = Math.min(6, Math.max(2, Number(playersCountEl?.value || 2)));
      await setPlayersCount(n);
    });
    document.getElementById("btnResetScores")?.addEventListener("click", async () => {
      await resetScores();
    });

    // ------------------------
    // initial load
    // ------------------------
    setStatus("⏳ Загружаем игру...");
    currentGame = await loadGame();
    setStatus(`🎮 ${currentGame.title} | phase: ${currentGame.phase}`);
    log(currentGame);

    // players
    players = await loadPlayers();
    idxBase = detectIdxBase(players);

    if (!players.length) {
      await setPlayersCount(2);
    } else {
      renderPlayersHost();
    }

    // ------------------------
    // realtime
    // ------------------------
    db.channel(`host:${gameId}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "games", filter: `id=eq.${gameId}` },
        (payload) => {
          currentGame = payload.new;
          setStatus(`🎮 ${payload.new.title} | phase: ${payload.new.phase}`);
          log(payload.new);
        }
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "players", filter: `game_id=eq.${gameId}` },
        async () => {
          players = await loadPlayers();
          idxBase = detectIdxBase(players);
          renderPlayersHost();
        }
      )
      .subscribe();
  } catch (e) {
    console.error(e);
    const msg = e?.message || String(e);
    const details = e?.details || "";
    setStatus(`❌ Ошибка: ${msg}${details ? " — " + details : ""}`);
    log(e);
  }
})();
