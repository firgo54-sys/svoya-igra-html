// assets/js/play.js
// Этот файл подключается обычным <script src="../assets/js/play.js"></script>
// Поэтому НЕЛЬЗЯ использовать top-level await. Всё запускаем внутри async init().

(async function init() {
  const params = new URLSearchParams(window.location.search);

  // TV mode
  if (params.get("tv") === "1") document.documentElement.classList.add("tv");

  const gameId = params.get("gameId");
  if (!gameId) {
    alert("gameId не передан");
    throw new Error("gameId missing");
  }

  if (!window.supabase) {
    alert("Supabase не подключен (проверь supabase.js)");
    throw new Error("supabase missing");
  }

  const supabase = window.supabase;

  let players = [];
  const playersBarEl = document.getElementById("playersBar");

  // ------------------------
  // Round (какой раунд показывать на табло)
  // 1) ?round=1
  // 2) games.round / games.current_round (если есть)
  // 3) по умолчанию 1
  // ------------------------
  let currentRound = Number(params.get("round") || 0) || 1;

  // ------------------------
  // UI helpers (board/question)
  // ------------------------
  function showBoard() {
    document.querySelector(".board-wrapper")?.classList.remove("hidden");
    document.getElementById("questionScreen")?.classList.add("hidden");
  }

  function showQuestionScreen() {
    document.querySelector(".board-wrapper")?.classList.add("hidden");
    document.getElementById("questionScreen")?.classList.remove("hidden");
  }

  function resetMedia() {
    const img = document.getElementById("qImage");
    const aud = document.getElementById("qAudio");

    if (img) {
      img.src = "";
      img.classList.add("hidden");
    }
    if (aud) {
      try {
        aud.pause();
      } catch {}
      aud.src = "";
      aud.classList.add("hidden");
    }
  }

  // ------------------------
  // players render
  // ------------------------
  function renderPlayersBar() {
    if (!playersBarEl) return;

    playersBarEl.innerHTML = "";

    players.forEach((p) => {
      const chip = document.createElement("div");
      chip.className = "player-chip";

      const img = document.createElement("img");
      img.alt = p.name || `Игрок ${p.idx}`;

      // ✅ чтобы аватар точно обновлялся (anti-cache)
      if (p.avatar_url) {
        const sep = p.avatar_url.includes("?") ? "&" : "?";
        img.src = `${p.avatar_url}${sep}v=${Date.now()}`;
      } else {
        img.src = "";
        img.style.visibility = "hidden";
      }

      const nm = document.createElement("div");
      nm.className = "nm";
      nm.textContent = p.name || `Игрок ${p.idx}`;

      const sc = document.createElement("div");
      sc.className = "sc";
      sc.textContent = String(p.score ?? 0);

      chip.appendChild(img);
      chip.appendChild(nm);
      chip.appendChild(sc);

      playersBarEl.appendChild(chip);
    });
  }

  // ------------------------
  // TOPICS: load + render into board
  // ------------------------
  async function loadTopics(round) {
    const { data, error } = await supabase
      .from("topics")
      .select("id, game_id, round, idx, title")
      .eq("game_id", gameId)
      .eq("round", round)
      .order("idx", { ascending: true });

    if (error) {
      console.error("loadTopics error:", error);
      return [];
    }
    return data || [];
  }

  function renderTopicsIntoBoard(topics) {
    // Ищем все ячейки тем в табло (левая колонка)
    const topicCells = Array.from(document.querySelectorAll(".board .topic"));

    // если табло вообще не найдено — молча выходим
    if (!topicCells.length) return;

    // Заполняем по порядку
    for (let i = 0; i < topicCells.length; i++) {
      const cell = topicCells[i];

      // Берём тему по idx (0..4) если есть, иначе по порядку
      const byIdx = topics.find((t) => Number(t.idx) === i);
      const t = byIdx || topics[i];

      if (t && (t.title || "").trim()) {
        cell.textContent = t.title.trim();
      } else {
        // fallback (если в базе пусто)
        cell.textContent = `ТЕМА ${i + 1}`;
      }
    }
  }

  async function refreshTopics() {
    const topics = await loadTopics(currentRound);
    renderTopicsIntoBoard(topics);
  }

  // ------------------------
  // load question
  // ------------------------
  async function loadQuestion(questionId) {
    const { data, error } = await supabase
      .from("questions")
      .select("*")
      .eq("id", questionId)
      .single();

    if (error) {
      console.error("loadQuestion error:", error);
      return null;
    }
    return data;
  }

  // ------------------------
  // apply game state (board/question/answer)
  // ------------------------
  async function applyGameState(game) {
    if (!game) return;

    // если в games есть поле round/current_round — подхватим автоматически
    const gameRound = Number(game.current_round || game.round || 0) || 0;
    if (gameRound && gameRound !== currentRound) {
      currentRound = gameRound;
      await refreshTopics();
    }

    if (game.phase === "board") {
      showBoard();
      return;
    }

    if (!game.active_question_id) return;

    const q = await loadQuestion(game.active_question_id);
    if (!q) return;

    showQuestionScreen();
    resetMedia();

    const qTopic = document.getElementById("qTopic");
    const qValue = document.getElementById("qValue");
    const qPrompt = document.getElementById("qPrompt");
    const qAnswer = document.getElementById("qAnswer");

    // (если хочешь — можем позже сюда подставить название темы из topics)
    if (qTopic) qTopic.textContent = "";
    if (qValue) qValue.textContent = q.value ? `${q.value}` : "";
    if (qPrompt) qPrompt.textContent = q.prompt || "";

    if (q.type === "image" && q.media_url) {
      const img = document.getElementById("qImage");
      if (img) {
        img.src = q.media_url;
        img.classList.remove("hidden");
      }
    }

    if (q.type === "audio" && q.media_url) {
      const aud = document.getElementById("qAudio");
      if (aud) {
        aud.src = q.media_url;
        aud.classList.remove("hidden");
      }
    }

    if (qAnswer) {
      qAnswer.textContent = q.answer || "";
      if (game.phase === "answer" || game.show_answer) qAnswer.classList.remove("hidden");
      else qAnswer.classList.add("hidden");
    }
  }

  // ------------------------
  // load players
  // ------------------------
  async function loadPlayers() {
    const { data, error } = await supabase
      .from("players")
      .select("*")
      .eq("game_id", gameId)
      .order("idx", { ascending: true });

    if (error) {
      console.error("loadPlayers error:", error);
      return [];
    }
    return data || [];
  }

  // ------------------------
  // initial load
  // ------------------------
  // 1) темЫ сразу (чтобы не было “ТЕМА 1”)
  await refreshTopics();

  // 2) загрузка игры + состояние
  const { data: game, error: gameErr } = await supabase
    .from("games")
    .select("*")
    .eq("id", gameId)
    .single();

  if (!gameErr) {
    await applyGameState(game);
  } else {
    console.error("load game error:", gameErr);
  }

  // 3) игроки
  players = await loadPlayers();
  renderPlayersBar();

  // ------------------------
  // realtime: games + players + topics
  // ------------------------
  supabase
    .channel(`play:${gameId}`)
    .on(
      "postgres_changes",
      { event: "UPDATE", schema: "public", table: "games", filter: `id=eq.${gameId}` },
      async (payload) => {
        await applyGameState(payload.new);
      }
    )
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "players", filter: `game_id=eq.${gameId}` },
      async () => {
        players = await loadPlayers();
        renderPlayersBar();
      }
    )
    .on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "topics",
        filter: `game_id=eq.${gameId}`,
      },
      async () => {
        // темы могли поменяться в editor — перерисуем левую колонку
        await refreshTopics();
      }
    )
    .subscribe();
})();
