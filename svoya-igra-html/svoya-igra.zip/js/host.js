// assets/js/host.js
// Улучшения:
// 1) Очки обновляются сразу (не ждём Realtime)
// 2) Начисление по номиналу активного вопроса (если активного вопроса нет — спросит сумму)
// 3) Работает как обычный <script> (без module), без top-level await

(async function init() {
  const urlParams = new URLSearchParams(window.location.search);
  const gameId = urlParams.get('gameId');

  const statusEl = document.getElementById('status');
  const debugEl = document.getElementById('debug');

  const playersCountEl = document.getElementById('playersCount');
  const playersListHostEl = document.getElementById('playersListHost');

  let currentGame = null;
  let players = [];

  function setStatus(t) {
    if (statusEl) statusEl.textContent = t;
  }
  function log(obj) {
    if (!debugEl) return;
    debugEl.textContent = typeof obj === 'string' ? obj : JSON.stringify(obj, null, 2);
  }

  try {
    if (!gameId) {
      setStatus('❌ gameId не передан');
      throw new Error('gameId missing');
    }

    if (!window.supabase) {
      setStatus('❌ window.supabase пуст (supabase.js не подключился)');
      return;
    }

    const db = window.supabase;

    // ------------------------
    // helpers
    // ------------------------
    async function updateGame(patch) {
      const { error } = await db.from('games').update(patch).eq('id', gameId);
      if (error) throw error;
    }

    async function loadGame() {
      const { data, error } = await db.from('games').select('*').eq('id', gameId).single();
      if (error) throw error;
      return data;
    }

    async function loadPlayers() {
      const { data, error } = await db
        .from('players')
        .select('*')
        .eq('game_id', gameId)
        .order('idx', { ascending: true });

      if (error) throw error;
      return data || [];
    }

    // ✅ ВАЖНО: сразу перерисовываем UI после апдейта (не ждём realtime)
    async function updatePlayer(idx, patch) {
      const { error } = await db
        .from('players')
        .update(patch)
        .eq('game_id', gameId)
        .eq('idx', idx);

      if (error) throw error;

      players = await loadPlayers();
      renderPlayersHost();
    }

    async function insertMissingPlayers(targetCount) {
      const existingIdx = new Set(players.map(p => p.idx));
      const toInsert = [];

      for (let i = 1; i <= targetCount; i++) {
        if (!existingIdx.has(i)) {
          toInsert.push({ game_id: gameId, idx: i, name: `Игрок ${i}`, score: 0, avatar_url: null });
        }
      }

      if (toInsert.length) {
        const { error } = await db.from('players').insert(toInsert);
        if (error) throw error;
      }
    }

    async function deleteExtraPlayers(targetCount) {
      const { error } = await db.from('players').delete().eq('game_id', gameId).gt('idx', targetCount);
      if (error) throw error;
    }

    async function setPlayersCount(targetCount) {
      await insertMissingPlayers(targetCount);
      await deleteExtraPlayers(targetCount);
      players = await loadPlayers();
      renderPlayersHost();
    }

    async function resetScores() {
      const { error } = await db.from('players').update({ score: 0 }).eq('game_id', gameId);
      if (error) throw error;

      players = await loadPlayers();
      renderPlayersHost();
    }

    // ✅ берём номинал активного вопроса; если нет активного — спросим сумму
    async function getAwardValue() {
      if (currentGame?.active_question_id) {
        const { data, error } = await db
          .from('questions')
          .select('value')
          .eq('id', currentGame.active_question_id)
          .single();

        if (!error && data?.value != null) {
          const v = Number(data.value);
          if (Number.isFinite(v)) return v;
        }
      }

      const raw = prompt('Сколько начислить? (число)', '100');
      const n = Number(raw);
      return Number.isFinite(n) ? n : 100;
    }

    async function uploadAvatarJPEG(file, idx) {
      if (!file) return null;

      const isJpeg =
        file.type === 'image/jpeg' ||
        file.name.toLowerCase().endsWith('.jpg') ||
        file.name.toLowerCase().endsWith('.jpeg');

      if (!isJpeg) {
        alert('Только JPEG (jpg/jpeg)');
        return null;
      }

      const path = `${gameId}/player-${idx}.jpg`;

      const { error: upErr } = await db.storage
        .from('avatars')
        .upload(path, file, { upsert: true, contentType: 'image/jpeg' });

      if (upErr) throw upErr;

      const { data } = db.storage.from('avatars').getPublicUrl(path);
      return data?.publicUrl || null;
    }

    function renderPlayersHost() {
      if (!playersListHostEl) return;
      playersListHostEl.innerHTML = '';

      players.forEach(p => {
        const card = document.createElement('div');
        card.className = 'player-card';

        const img = document.createElement('img');
        img.className = 'player-avatar';
        img.alt = p.name || `Игрок ${p.idx}`;
        img.src = p.avatar_url || '';
        if (!p.avatar_url) img.style.visibility = 'hidden';

        const meta = document.createElement('div');
        meta.className = 'player-meta';

        const row = document.createElement('div');
        row.className = 'player-row';

        const nameInput = document.createElement('input');
        nameInput.className = 'player-name';
        nameInput.value = p.name || `Игрок ${p.idx}`;
        nameInput.placeholder = `Игрок ${p.idx}`;
        nameInput.addEventListener('change', async () => {
          try {
            const nextName = nameInput.value.trim() || `Игрок ${p.idx}`;
            await updatePlayer(p.idx, { name: nextName });
          } catch (e) {
            console.error(e);
            alert('Ошибка сохранения имени');
          }
        });

        const scoreBox = document.createElement('div');
        scoreBox.className = 'player-score';
        scoreBox.textContent = String(p.score ?? 0);

        row.appendChild(nameInput);
        row.appendChild(scoreBox);

        const actions = document.createElement('div');
        actions.className = 'player-actions';

        const btnMinus = document.createElement('button');
        btnMinus.type = 'button';
        btnMinus.textContent = '−';
        btnMinus.title = 'Минус (номинал активного вопроса)';
        btnMinus.addEventListener('click', async () => {
          try {
            const v = await getAwardValue();
            await updatePlayer(p.idx, { score: (p.score ?? 0) - v });
          } catch (e) { console.error(e); }
        });

        const btnPlus = document.createElement('button');
        btnPlus.type = 'button';
        btnPlus.textContent = '+';
        btnPlus.title = 'Плюс (номинал активного вопроса)';
        btnPlus.addEventListener('click', async () => {
          try {
            const v = await getAwardValue();
            await updatePlayer(p.idx, { score: (p.score ?? 0) + v });
          } catch (e) { console.error(e); }
        });

        const btnZero = document.createElement('button');
        btnZero.type = 'button';
        btnZero.textContent = '0';
        btnZero.title = 'Сброс игрока';
        btnZero.addEventListener('click', async () => {
          try { await updatePlayer(p.idx, { score: 0 }); } catch (e) { console.error(e); }
        });

        const upload = document.createElement('input');
        upload.type = 'file';
        upload.accept = 'image/jpeg,.jpg,.jpeg';
        upload.className = 'player-upload';
        upload.addEventListener('change', async () => {
          try {
            const file = upload.files?.[0];
            if (!file) return;
            const url = await uploadAvatarJPEG(file, p.idx);
            if (url) await updatePlayer(p.idx, { avatar_url: url });
            upload.value = '';
          } catch (e) {
            console.error(e);
            alert('Ошибка загрузки аватара (проверь bucket avatars public + policies)');
          }
        });

        actions.appendChild(btnMinus);
        actions.appendChild(btnPlus);
        actions.appendChild(btnZero);
        actions.appendChild(upload);

        meta.appendChild(row);
        meta.appendChild(actions);

        card.appendChild(img);
        card.appendChild(meta);

        playersListHostEl.appendChild(card);
      });

      if (playersCountEl) {
        const n = Math.min(6, Math.max(2, players.length || 2));
        playersCountEl.value = String(n);
      }
    }

    // ------------------------
    // bind buttons (phase)
    // ------------------------
    document.getElementById('btnBoard')?.addEventListener('click', async () => {
      try { await updateGame({ phase: 'board', active_question_id: null, show_answer: false }); }
      catch (e) { console.error(e); }
    });
    document.getElementById('btnShowAnswer')?.addEventListener('click', async () => {
      try { await updateGame({ phase: 'answer', show_answer: true }); }
      catch (e) { console.error(e); }
    });
    document.getElementById('btnBackToBoard')?.addEventListener('click', async () => {
      try { await updateGame({ phase: 'board', active_question_id: null, show_answer: false }); }
      catch (e) { console.error(e); }
    });

    // players controls
    document.getElementById('btnApplyPlayers')?.addEventListener('click', async () => {
      try {
        const n = Math.min(6, Math.max(2, Number(playersCountEl?.value || 2)));
        await setPlayersCount(n);
      } catch (e) { console.error(e); }
    });
    document.getElementById('btnResetScores')?.addEventListener('click', async () => {
      try { await resetScores(); } catch (e) { console.error(e); }
    });

    // ------------------------
    // initial load
    // ------------------------
    setStatus('⏳ Загружаем игру...');
    currentGame = await loadGame();
    setStatus(`🎮 ${currentGame.title} | phase: ${currentGame.phase}`);
    log(currentGame);

    players = await loadPlayers();
    if (!players.length) {
      await setPlayersCount(2);
    } else {
      renderPlayersHost();
    }

    // ------------------------
    // realtime (если включено — дополнительно обновит)
    // ------------------------
    db.channel(`host:${gameId}`)
      .on('postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'games', filter: `id=eq.${gameId}` },
        payload => {
          currentGame = payload.new;
          setStatus(`🎮 ${payload.new.title} | phase: ${payload.new.phase}`);
          log(payload.new);
        }
      )
      .on('postgres_changes',
        { event: '*', schema: 'public', table: 'players', filter: `game_id=eq.${gameId}` },
        async () => {
          players = await loadPlayers();
          renderPlayersHost();
        }
      )
      .subscribe();

  } catch (e) {
    console.error(e);
    const msg = e?.message || String(e);
    const details = e?.details || '';
    setStatus(`❌ Ошибка: ${msg}${details ? ' — ' + details : ''}`);
    log(e);
  }
})();
