// assets/js/play.js
// Улучшения:
// 1) Всегда используем window.supabase (чтобы не было проблем с областью видимости)
// 2) Логи статуса Realtime-подписки
// 3) Fallback: авто-обновление игроков (polling), если Realtime не прилетает

(async function init() {
  const urlParams = new URLSearchParams(window.location.search);
  const gameId = urlParams.get('gameId');

  if (!gameId) {
    alert('gameId не передан');
    throw new Error('gameId missing');
  }

  if (!window.supabase) {
    alert('Supabase не подключён (window.supabase пуст). Проверь подключение supabase-js и supabase.js');
    throw new Error('supabase missing');
  }

  const db = window.supabase;

  let players = [];
  let lastPlayersFingerprint = '';

  const playersBarEl = document.getElementById('playersBar');

  // ------------------------
  // UI helpers (board/question)
  // ------------------------
  function showBoard() {
    document.querySelector('.board-wrapper')?.classList.remove('hidden');
    document.getElementById('questionScreen')?.classList.add('hidden');
  }

  function showQuestionScreen() {
    document.querySelector('.board-wrapper')?.classList.add('hidden');
    document.getElementById('questionScreen')?.classList.remove('hidden');
  }

  function resetMedia() {
    const img = document.getElementById('qImage');
    const aud = document.getElementById('qAudio');

    if (img) {
      img.src = '';
      img.classList.add('hidden');
    }
    if (aud) {
      aud.pause();
      aud.src = '';
      aud.classList.add('hidden');
    }
  }

  // ------------------------
  // players render
  // ------------------------
  function renderPlayersBar() {
    if (!playersBarEl) return;

    playersBarEl.innerHTML = '';

    players.forEach(p => {
      const chip = document.createElement('div');
      chip.className = 'player-chip';

      const img = document.createElement('img');
      img.alt = p.name || `Игрок ${p.idx}`;
      img.src = p.avatar_url || '';
      if (!p.avatar_url) img.style.visibility = 'hidden';

      const nm = document.createElement('div');
      nm.className = 'nm';
      nm.textContent = p.name || `Игрок ${p.idx}`;

      const sc = document.createElement('div');
      sc.className = 'sc';
      sc.textContent = String(p.score ?? 0);

      chip.appendChild(img);
      chip.appendChild(nm);
      chip.appendChild(sc);

      playersBarEl.appendChild(chip);
    });
  }

  // ------------------------
  // load question
  // ------------------------
  async function loadQuestion(questionId) {
    const { data, error } = await db
      .from('questions')
      .select('*')
      .eq('id', questionId)
      .single();

    if (error) {
      console.error('loadQuestion error:', error);
      return null;
    }
    return data;
  }

  // ------------------------
  // apply game state (board/question/answer)
  // ------------------------
  async function applyGameState(game) {
    if (!game) return;

    if (game.phase === 'board') {
      showBoard();
      return;
    }

    if (!game.active_question_id) return;

    const q = await loadQuestion(game.active_question_id);
    if (!q) return;

    showQuestionScreen();
    resetMedia();

    const qTopic = document.getElementById('qTopic');
    const qValue = document.getElementById('qValue');
    const qPrompt = document.getElementById('qPrompt');
    const qAnswer = document.getElementById('qAnswer');

    if (qTopic) qTopic.textContent = '';
    if (qValue) qValue.textContent = q.value ? `${q.value}` : '';
    if (qPrompt) qPrompt.textContent = q.prompt || '';

    if (q.type === 'image' && q.media_url) {
      const img = document.getElementById('qImage');
      if (img) {
        img.src = q.media_url;
        img.classList.remove('hidden');
      }
    }

    if (q.type === 'audio' && q.media_url) {
      const aud = document.getElementById('qAudio');
      if (aud) {
        aud.src = q.media_url;
        aud.classList.remove('hidden');
      }
    }

    if (qAnswer) {
      qAnswer.textContent = q.answer || '';
      if (game.phase === 'answer' || game.show_answer) qAnswer.classList.remove('hidden');
      else qAnswer.classList.add('hidden');
    }
  }

  // ------------------------
  // load players
  // ------------------------
  async function loadPlayers() {
    const { data, error } = await db
      .from('players')
      .select('*')
      .eq('game_id', gameId)
      .order('idx', { ascending: true });

    if (error) {
      console.error('loadPlayers error:', error);
      return [];
    }
    return data || [];
  }

  function fingerprintPlayers(list) {
    // компактный отпечаток, чтобы не перерисовывать зря
    return (list || [])
      .map(p => `${p.idx}:${p.name || ''}:${p.score ?? 0}:${p.avatar_url || ''}`)
      .join('|');
  }

  async function refreshPlayersIfChanged() {
    const next = await loadPlayers();
    const fp = fingerprintPlayers(next);
    if (fp !== lastPlayersFingerprint) {
      players = next;
      lastPlayersFingerprint = fp;
      renderPlayersBar();
    }
  }

  // ------------------------
  // initial load
  // ------------------------
  const { data: game, error: gameErr } = await db
    .from('games')
    .select('*')
    .eq('id', gameId)
    .single();

  if (!gameErr) {
    await applyGameState(game);
  } else {
    console.error('load game error:', gameErr);
  }

  players = await loadPlayers();
  lastPlayersFingerprint = fingerprintPlayers(players);
  renderPlayersBar();

  // ------------------------
  // realtime: games + players
  // ------------------------
  const channel = db
    .channel(`play:${gameId}`)
    .on(
      'postgres_changes',
      { event: 'UPDATE', schema: 'public', table: 'games', filter: `id=eq.${gameId}` },
      async payload => {
        console.log('[realtime games UPDATE]', payload);
        await applyGameState(payload.new);
      }
    )
    .on(
      'postgres_changes',
      { event: '*', schema: 'public', table: 'players', filter: `game_id=eq.${gameId}` },
      async payload => {
        console.log('[realtime players *]', payload);
        await refreshPlayersIfChanged(); // ✅ сразу обновляем
      }
    );

  channel.subscribe(status => {
    console.log('[realtime subscribe status]', status);
  });

  // ------------------------
  // fallback polling (если realtime не работает)
  // ------------------------
  setInterval(() => {
    refreshPlayersIfChanged().catch(err => console.error('polling refreshPlayers error', err));
  }, 1500);
})();
